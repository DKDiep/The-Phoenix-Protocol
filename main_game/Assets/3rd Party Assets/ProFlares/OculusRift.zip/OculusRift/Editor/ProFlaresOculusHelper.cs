/// ProFlares - v1.08 - Copyright 2013-2014 All rights reserved - ProFlares.com
	
	/// <summary>
	/// ProFlaresOculusHelper.cs
	/// Helper class that contains a number of functions that other Editor Scripts use.
	/// </summary>
	
	using UnityEngine;
using UnityEditor;
using System.Collections;

public class ProFlaresOculusHelper : MonoBehaviour {
	const int menuPos = 10000;
	
	static int FlaresLeftLayer = 8;
	static int FlaresRightLayer = 9;
	
	
	[MenuItem ("Window/ProFlares/Create VR Setup On Selected OVR Camera",false,menuPos+30)]
	static void CreateVRFlareBatchCamera () {
		
		OVRCameraRig _OVRCameraRig = null;
		GameObject OVR_GO = null;
		
		if(Selection.activeGameObject){
			
			_OVRCameraRig = Selection.activeGameObject.GetComponent<OVRCameraRig>();
			
			if(_OVRCameraRig == null){
				Debug.LogError("ProFlares - Please Select Your OVRCameraRig");
				return;
			}else{
				OVR_GO = Selection.activeGameObject;
			}
		}else{
			Debug.LogError("ProFlares - Nothing Selected");
			return;
		}
		
		Camera[] cameras = OVR_GO.GetComponentsInChildren<Camera>();
		
		Transform CameraLeft = null;
		
		//		Transform CameraRight = null;
		
		for (int i = 0; i < cameras.Length; i++)
		{
			if(cameras[i].name == "LeftEyeAnchor")
				CameraLeft = cameras[i].transform;
			
			//			if(cameras[i].name == "RightEyeAnchor")
			//				CameraRight = cameras[i].transform;
		}
		
		
		GameObject batchGOLeft = new GameObject("ProFlareBatch_VR");
		
		batchGOLeft.layer = ProFlaresOculusHelper.FlaresLeftLayer;
		
		batchGOLeft.transform.parent = CameraLeft;
		
		batchGOLeft.transform.localPosition = Vector3.zero;
		
		batchGOLeft.transform.localRotation = Quaternion.identity;
		
		batchGOLeft.transform.localScale = Vector3.one;
		
		ProFlareBatch batchLeft = batchGOLeft.AddComponent<ProFlareBatch>();
		
		batchLeft.FlareCamera = CameraLeft.GetComponent<Camera>();
		
		batchLeft.FlareCameraTrans = CameraLeft;
		
		batchLeft.GameCamera = CameraLeft.GetComponent<Camera>();
		
		//		int layerMaskLeft = CameraLeft.GetComponent<Camera>().cullingMask;
		
		batchLeft.mode = ProFlareBatch.Mode.VR;
		
		batchLeft.SingleCamera_Mode = false;
		batchLeft.VR_Mode = true;
		

		batchLeft.zPos = 1;
	}
}